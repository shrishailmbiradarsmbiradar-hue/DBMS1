# OptiPrice: Retail Markdown Clearance & Pricing Strategy Dashboard

An interactive, responsive single-page analytics application designed for retail managers to model price elasticity, simulate markdown clearance schedules, scan slow-moving inventory, and analyze real-time market trends.

---

## 🚀 Key Features

* **Overview Analytics Dashboard**: Monitor projected revenue, gross margin %, sell-through rate (STR), and total markdown costs. Includes an automated advisor that offers pricing guidelines.
* **Clearance markdown Simulator (What-If Analysis)**: Set starting inventory, base pricing, unit COGS, sales velocity, and elasticity coefficient. Adjust progressive weekly discounts (Weeks 1–6) to simulate stock runoff curves.
* **Exhaustive clearance Schedule Optimizer**: An optimization algorithm that evaluates all 3,003 valid non-decreasing progressive markdown schedules (in steps of 10%) under 1ms to return the global profit-maximizing path.
* **Price Elasticity &regular Optimizer**: Graph price-vs-quantity linear demand curves ($Q = A - BP$) and revenue/profit curves. Calculates the analytical optimum price $P^* = \frac{A + B \cdot \text{COGS}}{2B}$ for profit maximization.
* **Slow-Moving Inventory Alert Panel**: Track aging stocks and sell-through rates across categories. Filter candidates for discounts and apply bulk markdowns.
* **Real-time Market Indicator (Reliance CSV Sync)**: Features a real-time CSV parser and playback feed. Reads historical stock data, simulates market trends, and dynamically couples market performance to retail price elasticity in real time!

---

## 📊 Analytical Mathematical Models

### 1. Power-Law clearance runoff
To model discount demand acceleration, the clearance engine computes:
$$Q_t = Q_{\text{base}, t} \cdot (1 - d_t)^{-e}$$
where:
* $Q_t$ is the week's demand volume.
* $Q_{\text{base}, t}$ is the baseline demand decayed over time ($Q_{\text{base}, 0} \cdot 0.95^t$).
* $d_t$ is the discount percentage (0 to 1).
* $e$ is the price elasticity coefficient.

### 2. Analytical Profit Maximizer
Regular price optimization utilizes a linear demand system to locate the peak of the quadratic profit function:
$$P^* = \frac{A}{2B} + \frac{\text{COGS}}{2}$$

---

## 🛠️ Tech Stack

* **Structure**: HTML5 (Semantic elements)
* **Styling**: Custom CSS3 (CSS Custom Properties, Glassmorphism, Theme support)
* **Logic**: Vanilla ES6 JavaScript (No external framework dependencies)
* **Charts**: Chart.js (via CDN)
* **Dataset**: Reliance 1-Year Stock Data CSV (`reliance_1year_stock_data.csv`)

---

## ⚙️ How to Run Locally

Since the application fetches and parses the local stock CSV in real-time, it requires a local web server (to bypass CORS restrictions).

1. Clone or download this repository.
2. Navigate to the project folder and run a simple HTTP server:
   ```bash
   # Using Node.js (http-server)
   npx http-server -p 8080
   
   # Or using Python 3
   python -m http.server 8080
   ```
3. Open your browser and go to [http://127.0.0.1:8080](http://127.0.0.1:8080).
