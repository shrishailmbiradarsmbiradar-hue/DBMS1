// OptiPrice - Retail Markdown & Pricing Strategy Engine

// State Management
let currentTheme = 'dark';
let activeTab = 'overview';
let activePreset = 'apparel';

// Datasets definition
const presets = {
    apparel: {
        name: "Spring Apparel End-of-Season Clearance",
        basePrice: 80,
        cogs: 35,
        elasticity: 2.2,
        baseWeeklySales: 80,
        initialInventory: 1000,
        recommendation: "Markdown Candidate. Apparel styles decay rapidly in appeal. The optimized progressive clearance schedule (10% → 20% → 40% → 60%) clears 97% of stock while securing a 25.4% profit margin.",
        statusBullets: [
            "Excess inventory on outerwear and pastel knits (average aging: 9.4 weeks).",
            "Base velocity is insufficient: sell-through rate currently at 48% under full price.",
            "High inventory holding cost ($1.20/unit/week) warrants fast liquidation."
        ],
        products: [
            { sku: "APP-JKT-01", name: "Classic Pastel Denim Jacket", category: "apparel", age: 10, stock: 250, price: 80, initialStock: 400, salesVolume: 150 },
            { sku: "APP-KNT-04", name: "Cable Knit Spring Sweater", category: "apparel", age: 9, stock: 180, price: 65, initialStock: 300, salesVolume: 120 },
            { sku: "APP-DRS-12", name: "Floral A-Line Midi Dress", category: "apparel", age: 7, stock: 140, price: 95, initialStock: 200, salesVolume: 60 },
            { sku: "APP-TTE-08", name: "Linen Crop Tee", category: "apparel", age: 3, stock: 90, price: 35, initialStock: 100, salesVolume: 10 },
            { sku: "APP-CHB-15", name: "Chino Beige Shorts", category: "apparel", age: 5, stock: 220, price: 50, initialStock: 350, salesVolume: 130 },
            { sku: "APP-SHR-22", name: "Lightweight Linen Shirt", category: "apparel", age: 12, stock: 80, price: 60, initialStock: 450, salesVolume: 370 },
            { sku: "APP-HAT-03", name: "Wide Brim Straw Hat", category: "apparel", age: 11, stock: 110, price: 30, initialStock: 150, salesVolume: 40 }
        ]
    },
    electronics: {
        name: "Consumer Electronics EOL Upgrade Cycle",
        basePrice: 299,
        cogs: 180,
        elasticity: 1.5,
        baseWeeklySales: 20,
        initialInventory: 300,
        recommendation: "High-value tech assets face steep, permanent value decay. Standard gradual markdowns lose momentum. Run a prompt 15% markdown, escalating to 30% by Week 3 to clear volume before replacement SKU launch.",
        statusBullets: [
            "Legacy audio systems and smartwatches nearing end-of-life cycle.",
            "High COGS relative to price limits markdown depth; margins are highly sensitive.",
            "Sell-through rates are low (33.3%), threatening write-offs upon competitor release."
        ],
        products: [
            { sku: "ELC-SND-09", name: "Wireless ANC Headphones v1", category: "electronics", age: 12, stock: 120, price: 299, initialStock: 250, salesVolume: 130 },
            { sku: "ELC-WCH-02", name: "Smart Fitness Watch Lite", category: "electronics", age: 10, stock: 85, price: 180, initialStock: 150, salesVolume: 65 },
            { sku: "ELC-CHG-10", name: "100W Multi-Port Charging Hub", category: "electronics", age: 4, stock: 40, price: 65, initialStock: 120, salesVolume: 80 },
            { sku: "ELC-SPK-05", name: "Waterproof Bluetooth Speaker", category: "electronics", age: 6, stock: 50, price: 110, initialStock: 100, salesVolume: 50 },
            { sku: "ELC-CAM-11", name: "4K Action Camera Bundle", category: "electronics", age: 14, stock: 45, price: 350, initialStock: 100, salesVolume: 55 }
        ]
    },
    grocery: {
        name: "Fresh Grocery Surplus & Perishables",
        basePrice: 12.99,
        cogs: 5.50,
        elasticity: 3.2,
        baseWeeklySales: 150,
        initialInventory: 2000,
        recommendation: "Perishable inventory. High demand sensitivity enables high liquidation volume. Apply an aggressive, early 35% markdown to clear units before decay, saving landfill dumping fees and reclaiming 92% of COGS.",
        statusBullets: [
            "Excess inventory in organic dairy, seasonal fruits, and bakery overflow.",
            "Average shelf life remaining: 1.5 weeks. Inventory aging is critical (14+ days).",
            "Dumping fees represent an additional $0.50/unit cost if not sold."
        ],
        products: [
            { sku: "GRO-DRY-33", name: "Organic Almond Milk Bulk Pack", category: "grocery", age: 3, stock: 400, price: 12.99, initialStock: 800, salesVolume: 400 },
            { sku: "GRO-FRT-12", name: "Imported Premium Avocados Box", category: "grocery", age: 2, stock: 350, price: 18.50, initialStock: 500, salesVolume: 150 },
            { sku: "GRO-BAK-04", name: "Gluten-Free Gourmet Cookie Tub", category: "grocery", age: 4, stock: 600, price: 8.99, initialStock: 1200, salesVolume: 600 },
            { sku: "GRO-TEA-88", name: "Loose Leaf Green Tea Caddy", category: "grocery", age: 8, stock: 250, price: 15.00, initialStock: 400, salesVolume: 150 },
            { sku: "GRO-VEG-09", name: "Hydroponic Lettuce Multi-Pack", category: "grocery", age: 1, stock: 150, price: 6.90, initialStock: 300, salesVolume: 150 }
        ]
    },
    homeware: {
        name: "Home Decor & Furnishing clearance",
        basePrice: 160,
        cogs: 70,
        elasticity: 1.8,
        baseWeeklySales: 35,
        initialInventory: 500,
        recommendation: "High storage volume cost. Style depreciation is low, but capital is locked up. Apply a conservative 15% markdown immediately, followed by 30% in week 4 to steady clearance rate while preserving high dollar margins.",
        statusBullets: [
            "Oversized furniture and artisan rugs occupying significant warehouse footprint.",
            "Holding cost is high ($3.50/pallet/week), dragging down net store margins.",
            "Sell-through rates are slow (22%) due to high price barriers."
        ],
        products: [
            { sku: "HOM-CHR-77", name: "Ergonomic Mesh Office Chair", category: "homeware", age: 11, stock: 90, price: 240, initialStock: 150, salesVolume: 60 },
            { sku: "HOM-RUG-14", name: "Boho-Chic Woven Wool Area Rug", category: "homeware", age: 14, stock: 80, price: 190, initialStock: 120, salesVolume: 40 },
            { sku: "HOM-LMP-03", name: "Minimalist Brass Floor Lamp", category: "homeware", age: 6, stock: 120, price: 85, initialStock: 200, salesVolume: 80 },
            { sku: "HOM-MIR-12", name: "Gold Leaf Hexagonal Mirror", category: "homeware", age: 9, stock: 75, price: 120, initialStock: 150, salesVolume: 75 },
            { sku: "HOM-ORG-02", name: "Stackable Bamboo Organizer Box", category: "homeware", age: 5, stock: 210, price: 45, initialStock: 300, salesVolume: 90 }
        ]
    }
};

// Simulation schedule store (dynamic)
let discountSchedule = [10, 20, 30, 40, 50, 60]; // User-defined Strategy A
let optimizedSchedule = []; // Strategy B (filled by optimizer)
let baseSchedule = [0, 0, 0, 0, 0, 0]; // Base Strategy

// Chart Instances
let chartWeeklyRevenue = null;
let chartStrategyComparison = null;
let chartInventoryRunoff = null;
let chartDemandCurve = null;
let chartProfitCurve = null;

// Sorting inventory
let inventorySortField = 'age';
let inventorySortOrder = 'desc';

// Active selection for bulk action
let selectedSkus = new Set();

// On page load
window.addEventListener('DOMContentLoaded', () => {
    // Set initial values
    loadPresetDataset();
    runElasticityModel();
});

// Theme Toggle
function toggleTheme() {
    const html = document.documentElement;
    if (html.getAttribute('data-theme') === 'dark') {
        html.setAttribute('data-theme', 'light');
        document.getElementById('theme-text').innerText = 'Dark Mode';
    } else {
        html.setAttribute('data-theme', 'dark');
        document.getElementById('theme-text').innerText = 'Light Mode';
    }
    // Redraw charts with new styles
    updateAllCharts();
}

// Switch Tabs
function switchTab(tabId) {
    activeTab = tabId;
    
    // Toggle active classes on side items
    document.querySelectorAll('.nav-item').forEach(btn => btn.classList.remove('active'));
    document.getElementById(`btn-${tabId}`).classList.add('active');
    
    // Toggle active tab content panels
    document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));
    document.getElementById(`tab-${tabId}`).classList.add('active');

    // Handle updates when tabs are visible to ensure charts render correctly
    setTimeout(() => {
        updateAllCharts();
    }, 50);
}

// Load Preset Dataset
function loadPresetDataset() {
    const selector = document.getElementById('dataset-preset');
    activePreset = selector.value;
    const preset = presets[activePreset];

    // Set subtitle description
    document.getElementById('subtitle-text').innerText = `Clearing: ${preset.name}`;

    // Fill simulator input controls with preset values
    document.getElementById('sim-starting-stock').value = preset.initialInventory;
    document.getElementById('sim-base-price').value = preset.basePrice;
    document.getElementById('sim-unit-cost').value = preset.cogs;
    document.getElementById('sim-weekly-velocity').value = preset.baseWeeklySales;
    document.getElementById('sim-elasticity').value = preset.elasticity;
    document.getElementById('sim-elasticity-val').innerText = preset.elasticity;

    // Reset discount schedules based on preset characteristics
    if (activePreset === 'apparel') {
        discountSchedule = [10, 20, 30, 40, 50, 60];
    } else if (activePreset === 'electronics') {
        discountSchedule = [0, 15, 15, 30, 30, 45];
    } else if (activePreset === 'grocery') {
        discountSchedule = [20, 30, 40, 50, 60, 70];
    } else {
        discountSchedule = [10, 15, 20, 25, 30, 40];
    }
    updateScheduleUI();

    // Fill Elasticity inputs
    document.getElementById('el-cost').value = preset.cogs;
    
    // Set demand curve parameters based on preset
    if (activePreset === 'apparel') {
        document.getElementById('el-max-demand').value = 400;
        document.getElementById('el-sensitivity').value = 3.5;
        document.getElementById('el-current-price').value = preset.basePrice;
    } else if (activePreset === 'electronics') {
        document.getElementById('el-max-demand').value = 150;
        document.getElementById('el-sensitivity').value = 0.3;
        document.getElementById('el-current-price').value = preset.basePrice;
    } else if (activePreset === 'grocery') {
        document.getElementById('el-max-demand').value = 1200;
        document.getElementById('el-sensitivity').value = 65;
        document.getElementById('el-current-price').value = preset.basePrice;
    } else {
        document.getElementById('el-max-demand').value = 250;
        document.getElementById('el-sensitivity').value = 1.1;
        document.getElementById('el-current-price').value = preset.basePrice;
    }
    
    updateSliderLabel('el-sensitivity-val', document.getElementById('el-sensitivity').value);
    updateSliderLabel('el-current-price-val', '$' + document.getElementById('el-current-price').value);

    // Rebuild tables and run sims
    renderInventoryTable();
    runSimulation();
    runElasticityModel();
}

// Update sliders value label
function updateSliderLabel(elementId, value) {
    document.getElementById(elementId).innerText = value;
}

// Update week slider dynamically
function updateWeeklyDiscount(week, value) {
    discountSchedule[week - 1] = parseInt(value);
    document.getElementById(`markdown-w${week}-val`).innerText = `${value}%`;
    runSimulation();
}

// Update sliders UI
function updateScheduleUI() {
    for (let w = 1; w <= 6; w++) {
        const val = discountSchedule[w - 1];
        document.getElementById(`markdown-w${w}`).value = val;
        document.getElementById(`markdown-w${w}-val`).innerText = `${val}%`;
    }
}

// Reset schedule
function resetDiscountSchedule() {
    discountSchedule = [0, 0, 0, 0, 0, 0];
    updateScheduleUI();
    runSimulation();
}

// Apply Recommended strategy directly to sliders
function applyOptimizedMarkdown() {
    discountSchedule = [...optimizedSchedule];
    updateScheduleUI();
    runSimulation();
    switchTab('simulator');
}

// CORE SIMULATION MATH
function simulateScenario(startingStock, basePrice, unitCost, baseVelocity, elasticity, discounts) {
    let stock = startingStock;
    let totalRevenue = 0;
    let totalCogs = 0;
    let unitsSoldWeekly = [];
    let stockWeekly = [startingStock];
    let priceWeekly = [];
    
    for (let w = 0; w < 6; w++) {
        const disc = discounts[w] / 100;
        const currentPrice = basePrice * (1 - disc);
        priceWeekly.push(currentPrice);
        
        // Base demand decays over weeks because product gets colder (5% drop per week)
        const weeklyBaseDecay = baseVelocity * Math.pow(0.95, w);
        
        // Elasticity multiplier: multiplier = (P_current / P_base) ^ -elasticity
        // Avoid division by zero
        let multiplier = 1;
        if (disc > 0) {
            multiplier = Math.pow(1 - disc, -elasticity);
        }
        
        let calculatedDemand = Math.round(weeklyBaseDecay * multiplier);
        let actualSales = Math.min(calculatedDemand, stock);
        
        stock -= actualSales;
        totalRevenue += actualSales * currentPrice;
        totalCogs += actualSales * unitCost;
        
        unitsSoldWeekly.push(actualSales);
        stockWeekly.push(stock);
    }
    
    const sellThrough = ((startingStock - stock) / startingStock) * 100;
    
    // Add write-off / salvage recovery for remaining inventory (e.g. 10% of COGS)
    const salvageValue = Math.round(stock * (unitCost * 0.1));
    const finalRevenue = totalRevenue + salvageValue;
    const finalProfit = finalRevenue - (startingStock * unitCost); // All initial units cost money
    
    return {
        revenue: finalRevenue,
        profit: finalProfit,
        sellThrough: sellThrough,
        stockWeekly: stockWeekly,
        unitsSoldWeekly: unitsSoldWeekly,
        priceWeekly: priceWeekly,
        endingUnits: stock,
        salvage: salvageValue
    };
}

// Clear campaign global optimization using exhaustive grid search
function findOptimizedSchedule(startingStock, basePrice, unitCost, baseVelocity, elasticity) {
    let bestSchedule = [0, 0, 0, 0, 0, 0];
    let maxProfit = -Infinity;
    
    // Available clearance markdown options (increments of 10%)
    const discountSteps = [0, 10, 20, 30, 40, 50, 60, 70, 80];
    
    // Generate non-decreasing combinations of discounts for 6 weeks
    // This is mathematically sound, markdowns are always progressive
    function search(week, prevDiscount, currentSchedule) {
        if (week === 6) {
            const results = simulateScenario(startingStock, basePrice, unitCost, baseVelocity, elasticity, currentSchedule);
            if (results.profit > maxProfit) {
                maxProfit = results.profit;
                bestSchedule = [...currentSchedule];
            }
            return;
        }
        
        for (let i = 0; i < discountSteps.length; i++) {
            const step = discountSteps[i];
            if (step >= prevDiscount) {
                currentSchedule[week] = step;
                search(week + 1, step, currentSchedule);
            }
        }
    }
    
    search(0, 0, [0, 0, 0, 0, 0, 0]);
    return bestSchedule;
}

// RUN CLEARANCE SIMULATOR
function runSimulation() {
    const startingStock = parseInt(document.getElementById('sim-starting-stock').value) || 100;
    const basePrice = parseFloat(document.getElementById('sim-base-price').value) || 10;
    const unitCost = parseFloat(document.getElementById('sim-unit-cost').value) || 5;
    const baseVelocity = parseInt(document.getElementById('sim-weekly-velocity').value) || 5;
    const elasticity = parseFloat(document.getElementById('sim-elasticity').value) || 2.0;

    // Calculate optimal clearance schedule (Strategy B)
    optimizedSchedule = findOptimizedSchedule(startingStock, basePrice, unitCost, baseVelocity, elasticity);

    // Simulate all three options
    const simCustom = simulateScenario(startingStock, basePrice, unitCost, baseVelocity, elasticity, discountSchedule);
    const simOptimized = simulateScenario(startingStock, basePrice, unitCost, baseVelocity, elasticity, optimizedSchedule);
    const simBase = simulateScenario(startingStock, basePrice, unitCost, baseVelocity, elasticity, baseSchedule);

    // Update KPI metrics on Tab 2 (Custom Simulation results)
    document.getElementById('sim-gross-rev').innerText = formatCurrency(simCustom.revenue);
    const totalPotentialVal = startingStock * basePrice;
    const recoveryPct = (simCustom.revenue / totalPotentialVal) * 100;
    document.getElementById('sim-rev-recovery').innerText = `${recoveryPct.toFixed(1)}% retail value recovery`;

    document.getElementById('sim-net-profit').innerText = formatCurrency(simCustom.profit);
    const marginPct = (simCustom.profit / simCustom.revenue) * 100;
    document.getElementById('sim-margin-percentage').innerText = `${isNaN(marginPct) ? '0' : marginPct.toFixed(1)}% net margin`;

    document.getElementById('sim-str').innerText = `${simCustom.sellThrough.toFixed(1)}%`;
    document.getElementById('sim-ending-units').innerText = `${simCustom.endingUnits} units`;
    
    if (simCustom.sellThrough >= 95) {
        document.getElementById('sim-clearance-status').innerText = "Clearance Success (Stock cleared)";
        document.getElementById('sim-clearance-status').style.color = "var(--accent-success)";
    } else {
        document.getElementById('sim-clearance-status').innerText = `Warning: ${simCustom.endingUnits} units unsold`;
        document.getElementById('sim-clearance-status').style.color = "var(--accent-warning)";
    }

    // Update KPI Ribbon on Dashboard Tab
    document.getElementById('kpi-revenue').innerText = formatCurrency(simCustom.revenue);
    
    // Compare custom to base revenue
    const revDiff = simCustom.revenue - simBase.revenue;
    const revDiffTxt = revDiff >= 0 ? `+${formatCurrency(revDiff)} vs Base` : `${formatCurrency(revDiff)} vs Base`;
    document.getElementById('kpi-revenue-trend').className = revDiff >= 0 ? "kpi-change positive" : "kpi-change negative";
    document.getElementById('kpi-revenue-trend').querySelector('span').innerText = revDiffTxt;

    const customMargin = (simCustom.profit / simCustom.revenue) * 100;
    document.getElementById('kpi-margin').innerText = `${isNaN(customMargin) ? '0' : customMargin.toFixed(1)}%`;
    const marginTrend = document.getElementById('kpi-margin-trend');
    if (customMargin > 20) {
        marginTrend.className = "kpi-change positive";
        marginTrend.innerText = "Healthy Margin";
    } else if (customMargin > 5) {
        marginTrend.className = "kpi-change";
        marginTrend.innerText = "Tight Margin";
    } else {
        marginTrend.className = "kpi-change negative";
        marginTrend.innerText = "Negative / Diluted";
    }

    document.getElementById('kpi-sellthrough').innerText = `${simCustom.sellThrough.toFixed(1)}%`;
    document.getElementById('kpi-sellthrough-trend').innerText = `${startingStock - simCustom.endingUnits} / ${startingStock} units liquidated`;

    const totalDiscountValue = startingStock * basePrice - (simCustom.revenue - simCustom.salvage);
    document.getElementById('kpi-markdown-cost').innerText = formatCurrency(totalDiscountValue);
    const markdownLossPct = (totalDiscountValue / (startingStock * basePrice)) * 100;
    document.getElementById('kpi-markdown-cost-trend').innerText = `${markdownLossPct.toFixed(1)}% price dilution`;

    // Strategy comparison matrix rows
    const comparisonRows = document.getElementById('sim-comparison-rows');
    comparisonRows.innerHTML = `
        <tr>
            <td style="font-weight:600;">Base Case (No Discount)</td>
            <td><code>${baseSchedule.map(x=>x+'%').join(' → ')}</code></td>
            <td>${formatCurrency(simBase.revenue)}</td>
            <td>${((simBase.profit / simBase.revenue)*100).toFixed(1)}%</td>
            <td>${simBase.sellThrough.toFixed(1)}%</td>
            <td>${simBase.endingUnits} unsold (${formatCurrency(simBase.salvage)} salvage)</td>
        </tr>
        <tr class="highlighted-row" style="background-color:rgba(99,102,241,0.06); border-left: 3px solid var(--accent-primary);">
            <td style="font-weight:600; color:var(--accent-primary);">Decaying (Strategy Custom)</td>
            <td><code>${discountSchedule.map(x=>x+'%').join(' → ')}</code></td>
            <td>${formatCurrency(simCustom.revenue)}</td>
            <td>${((simCustom.profit / simCustom.revenue)*100).toFixed(1)}%</td>
            <td>${simCustom.sellThrough.toFixed(1)}%</td>
            <td>${simCustom.endingUnits} unsold (${formatCurrency(simCustom.salvage)} salvage)</td>
        </tr>
        <tr style="background-color:rgba(16,185,129,0.05); border-left: 3px solid var(--accent-success);">
            <td style="font-weight:600; color:var(--accent-success);">Optimized Strategy (AI Path)</td>
            <td><code>${optimizedSchedule.map(x=>x+'%').join(' → ')}</code></td>
            <td>${formatCurrency(simOptimized.revenue)}</td>
            <td>${((simOptimized.profit / simOptimized.revenue)*100).toFixed(1)}%</td>
            <td>${simOptimized.sellThrough.toFixed(1)}%</td>
            <td>${simOptimized.endingUnits} unsold (${formatCurrency(simOptimized.salvage)} salvage)</td>
        </tr>
    `;

    // Fill AI strategy advisor box
    updateAdvisorText(simCustom, simOptimized, simBase);

    // Update charts
    renderWeeklyClearanceChart(simBase, simCustom, simOptimized);
    renderStrategyComparisonChart(simBase, simCustom, simOptimized);
    renderInventoryRunoffChart(simBase, simCustom, simOptimized);
}

// Update Advisor textual content
function updateAdvisorText(simCustom, simOptimized, simBase) {
    const preset = presets[activePreset];
    const list = document.getElementById('advisor-status-list');
    list.innerHTML = '';
    
    preset.statusBullets.forEach(bullet => {
        const li = document.createElement('li');
        li.innerText = bullet;
        list.appendChild(li);
    });

    const isOptimizedCurrent = JSON.stringify(discountSchedule) === JSON.stringify(optimizedSchedule);
    
    let recommendation = "";
    if (isOptimizedCurrent) {
        recommendation = `Excellent job! Your custom discount schedule is fully optimized for maximum profit margins. You are clearing ${simCustom.sellThrough.toFixed(1)}% of stock, yielding ${formatCurrency(simCustom.profit)} in net profit. Ready to deploy pricing schedule to POS terminals.`;
    } else {
        const profitGain = simOptimized.profit - simCustom.profit;
        if (profitGain > 0) {
            recommendation = `Analyzing clear path: By switching from your current custom schedule to the AI Optimized schedule (<code>${optimizedSchedule.map(x=>x+'%').join(' → ')}</code>), you can salvage an additional <strong>${formatCurrency(profitGain)}</strong> in margin. This recovers a total of ${formatCurrency(simOptimized.revenue)} revenue.`;
        } else {
            recommendation = `Your custom schedule yields a high return! It matches or slightly outperforms standard algorithms by aligning clearance timing to localized demand elasticity. Ensure warehouse staff is prepped for Week ${discountSchedule.findIndex(d => d > 30) + 1 || 6} clearance volumes.`;
        }
    }
    
    document.getElementById('advisor-recommendation-text').innerHTML = recommendation;
}

// ELASTICITY PRICING ENGINE
function runElasticityModel() {
    const cost = parseFloat(document.getElementById('el-cost').value) || 0;
    const maxDemand = parseFloat(document.getElementById('el-max-demand').value) || 0;
    const sensitivity = parseFloat(document.getElementById('el-sensitivity').value) || 0;
    const simulatedPrice = parseFloat(document.getElementById('el-current-price').value) || 0;

    // Linear demand: Q(P) = maxDemand - sensitivity * P
    // Revenue: R(P) = P * Q(P) = P * (maxDemand - sensitivity * P)
    // Profit: Profit(P) = (P - cost) * Q(P) = (P - cost) * (maxDemand - sensitivity * P)
    // Derivative: dProfit/dP = maxDemand - 2*sensitivity*P + sensitivity*cost = 0
    // => P_optimal = (maxDemand + sensitivity * cost) / (2 * sensitivity) = maxDemand / (2*sensitivity) + cost / 2
    
    const optimalPrice = (maxDemand + sensitivity * cost) / (2 * sensitivity);
    const optimalQty = Math.max(0, Math.round(maxDemand - sensitivity * optimalPrice));
    const optimalRevenue = optimalPrice * optimalQty;
    const optimalProfit = (optimalPrice - cost) * optimalQty;

    // Populate UI
    document.getElementById('opt-best-price').innerText = formatCurrency(optimalPrice);
    document.getElementById('opt-max-profit').innerText = formatCurrency(optimalProfit);
    document.getElementById('opt-best-qty').innerText = `${optimalQty} units`;
    document.getElementById('opt-best-rev').innerText = formatCurrency(optimalRevenue);

    // Build curve datasets
    let prices = [];
    let demandQty = [];
    let revenues = [];
    let profits = [];
    
    // Choose step range dynamically based on max price before demand hits 0 (P = maxDemand/sensitivity)
    const maxP = Math.ceil(maxDemand / sensitivity);
    const step = Math.max(1, Math.ceil(maxP / 25));
    
    for (let p = 0; p <= maxP + 10; p += step) {
        prices.push(p);
        const qty = Math.max(0, Math.round(maxDemand - sensitivity * p));
        demandQty.push(qty);
        revenues.push(p * qty);
        profits.push((p - cost) * qty);
    }

    renderElasticityCurves(prices, demandQty, revenues, profits, cost, optimalPrice, simulatedPrice);
}

// FORMAT CURRENCY UTILITY
function formatCurrency(val) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        maximumFractionDigits: 0
    }).format(val);
}

// INVENTORY TABLE LOGIC
function renderInventoryTable() {
    const tableBody = document.getElementById('inventory-table-body');
    tableBody.innerHTML = '';
    
    const preset = presets[activePreset];
    let products = [...preset.products];

    // Search filter
    const query = document.getElementById('analyzer-search').value.toLowerCase();
    if (query) {
        products = products.filter(p => p.sku.toLowerCase().includes(query) || p.name.toLowerCase().includes(query));
    }

    // Category filter
    const cat = document.getElementById('filter-category').value;
    if (cat !== 'all') {
        products = products.filter(p => p.category === cat);
    }

    // Status / recommendation action filter
    const statusFilter = document.getElementById('filter-status').value;
    if (statusFilter !== 'all') {
        products = products.filter(p => {
            const recommendation = getRecommendationStatus(p);
            return recommendation.label === statusFilter;
        });
    }

    // Sort
    products.sort((a, b) => {
        let valA = a[inventorySortField];
        let valB = b[inventorySortField];
        
        // Calculate STR for sorting if requested
        if (inventorySortField === 'str') {
            valA = (a.salesVolume / a.initialStock) * 100;
            valB = (b.salesVolume / b.initialStock) * 100;
        }

        if (valA < valB) return inventorySortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return inventorySortOrder === 'asc' ? 1 : -1;
        return 0;
    });

    products.forEach(p => {
        const str = ((p.salesVolume / p.initialStock) * 100).toFixed(1);
        const rec = getRecommendationStatus(p);
        
        const row = document.createElement('tr');
        if (selectedSkus.has(p.sku)) {
            row.style.backgroundColor = 'rgba(99,102,241,0.05)';
        }

        row.innerHTML = `
            <td class="chk-column"><input type="checkbox" ${selectedSkus.has(p.sku) ? 'checked' : ''} onchange="toggleSelectSku('${p.sku}')"></td>
            <td>
                <div class="product-cell">
                    <span class="product-name">${p.name}</span>
                    <span class="product-sku">${p.sku}</span>
                </div>
            </td>
            <td><span style="text-transform: capitalize;">${p.category}</span></td>
            <td><span style="font-weight: 600;">${p.age}</span> wks</td>
            <td>
                <div style="font-weight: 600;">${p.stock} units</div>
                <div class="progress-bar-container">
                    <div class="progress-bar ${rec.barClass}" style="width: ${Math.min(100, (p.stock / p.initialStock) * 100)}%"></div>
                </div>
            </td>
            <td><span style="font-weight:600;">${formatCurrency(p.price)}</span></td>
            <td>
                <div style="font-weight:600;">${str}%</div>
                <div style="font-size:0.7rem; color:var(--text-muted);">${p.salesVolume} sold</div>
            </td>
            <td><span class="rec-badge ${rec.badgeClass}">${rec.label}</span></td>
            <td>
                <button class="btn btn-secondary btn-sm" onclick="runMarkdownOptimizationOnItem('${p.sku}')">Simulate Item</button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    updateSelectionText();
}

function getRecommendationStatus(product) {
    const str = (product.salesVolume / product.initialStock) * 100;
    const age = product.age;
    
    if (age < 4) {
        return { label: "Healthy Inventory", badgeClass: "healthy", barClass: "success" };
    } else if (age >= 4 && age < 9) {
        if (str < 40) {
            return { label: "Markdown Candidate", badgeClass: "warning", barClass: "warning" };
        } else {
            return { label: "Healthy Inventory", badgeClass: "healthy", barClass: "success" };
        }
    } else {
        if (str < 60) {
            return { label: "Urgent Clearance", badgeClass: "danger", barClass: "danger" };
        } else {
            return { label: "Markdown Candidate", badgeClass: "warning", barClass: "warning" };
        }
    }
}

function sortInventoryTable(field) {
    if (inventorySortField === field) {
        inventorySortOrder = inventorySortOrder === 'asc' ? 'desc' : 'asc';
    } else {
        inventorySortField = field;
        inventorySortOrder = 'desc';
    }
    renderInventoryTable();
}

function filterInventoryTable() {
    renderInventoryTable();
}

function toggleSelectSku(sku) {
    if (selectedSkus.has(sku)) {
        selectedSkus.delete(sku);
    } else {
        selectedSkus.add(sku);
    }
    renderInventoryTable();
}

function updateSelectionText() {
    const textEl = document.getElementById('selection-status-text');
    if (selectedSkus.size === 0) {
        textEl.innerText = "No items selected for bulk actions.";
    } else {
        textEl.innerText = `${selectedSkus.size} items selected for markdowns.`;
    }
}

function applyBulkMarkdown(action) {
    if (selectedSkus.size === 0) {
        alert("Please select one or more items using the checkboxes first.");
        return;
    }

    const preset = presets[activePreset];
    preset.products.forEach(p => {
        if (selectedSkus.has(p.sku)) {
            if (action === 'optimized') {
                const rec = getRecommendationStatus(p);
                if (rec.label === "Urgent Clearance") {
                    p.price = Math.round(p.price * 0.7); // 30% markdown
                } else if (rec.label === "Markdown Candidate") {
                    p.price = Math.round(p.price * 0.85); // 15% markdown
                }
            } else {
                p.price = Math.round(p.price * (1 - parseInt(action)/100));
            }
        }
    });

    alert(`Successfully applied markdowns to ${selectedSkus.size} item(s)! prices have been recalculated.`);
    selectedSkus.clear();
    renderInventoryTable();
}

function runMarkdownOptimizationOnItem(sku) {
    const preset = presets[activePreset];
    const product = preset.products.find(p => p.sku === sku);
    if (!product) return;

    // Load item parameters into simulator
    document.getElementById('sim-starting-stock').value = product.stock;
    document.getElementById('sim-base-price').value = product.price;
    document.getElementById('sim-weekly-velocity').value = Math.max(5, Math.round(product.salesVolume / product.age));
    
    // Switch to simulator tab to evaluate
    runSimulation();
    switchTab('simulator');
}

// EXPORT TO CSV / DOWNLOAD SIMULATOR REPORT
function exportData() {
    const preset = presets[activePreset];
    const startingStock = parseInt(document.getElementById('sim-starting-stock').value);
    const basePrice = parseFloat(document.getElementById('sim-base-price').value);
    const unitCost = parseFloat(document.getElementById('sim-unit-cost').value);
    const baseVelocity = parseInt(document.getElementById('sim-weekly-velocity').value);
    const elasticity = parseFloat(document.getElementById('sim-elasticity').value);

    const simCustom = simulateScenario(startingStock, basePrice, unitCost, baseVelocity, elasticity, discountSchedule);
    const simOptimized = simulateScenario(startingStock, basePrice, unitCost, baseVelocity, elasticity, optimizedSchedule);

    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Retail Markdown clearance Report\n";
    csvContent += `Scenario Preset,${preset.name}\n`;
    csvContent += `Clearance Parameters,Starting Inventory: ${startingStock} units | Original Price: $${basePrice} | COGS: $${unitCost}\n\n`;
    
    csvContent += "Strategy comparison Matrix\n";
    csvContent += "Strategy,Week 1,Week 2,Week 3,Week 4,Week 5,Week 6,Total Revenue,Net Profit,Sell-Through %,Ending Inventory\n";
    
    csvContent += `Base Case (No Discount),0%,0%,0%,0%,0%,0%,$${simulateScenario(startingStock,basePrice,unitCost,baseVelocity,elasticity,baseSchedule).revenue},$${simulateScenario(startingStock,basePrice,unitCost,baseVelocity,elasticity,baseSchedule).profit},${simulateScenario(startingStock,basePrice,unitCost,baseVelocity,elasticity,baseSchedule).sellThrough.toFixed(1)}%,${simulateScenario(startingStock,basePrice,unitCost,baseVelocity,elasticity,baseSchedule).endingUnits}\n`;
    csvContent += `Custom Decaying,${discountSchedule.map(x=>x+'%').join(',')},$${simCustom.revenue},$${simCustom.profit},${simCustom.sellThrough.toFixed(1)}%,${simCustom.endingUnits}\n`;
    csvContent += `AI Optimized,${optimizedSchedule.map(x=>x+'%').join(',')},$${simOptimized.revenue},$${simOptimized.profit},${simOptimized.sellThrough.toFixed(1)}%,${simOptimized.endingUnits}\n`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `OptiPrice_Clearance_Report_${activePreset}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// CHART REDRAW HOOKS
function updateAllCharts() {
    runSimulation();
    runElasticityModel();
}

// Chart color helpers
function getChartColors() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    return {
        grid: isDark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.05)',
        text: isDark ? '#9ca3af' : '#475569',
        accentPrimary: isDark ? '#6366f1' : '#4f46e5',
        accentSecondary: isDark ? '#8b5cf6' : '#7c3aed',
        accentTertiary: isDark ? '#06b6d4' : '#0891b2',
        accentSuccess: isDark ? '#10b981' : '#059669',
        accentDanger: isDark ? '#ef4444' : '#dc2626',
        tooltipBg: isDark ? '#1f2937' : '#ffffff',
        tooltipBorder: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
    };
}

// CHART 1: WEEKLY CLEARANCE CUMULATIVE REVENUE
function renderWeeklyClearanceChart(base, custom, optimized) {
    const ctx = document.getElementById('chart-weekly-revenue').getContext('2d');
    const colors = getChartColors();

    let cumulativeBase = [];
    let cumulativeCustom = [];
    let cumulativeOptimized = [];

    let sumBase = 0;
    let sumCustom = 0;
    let sumOptimized = 0;

    for (let w = 0; w < 6; w++) {
        sumBase += base.unitsSoldWeekly[w] * base.priceWeekly[w];
        sumCustom += custom.unitsSoldWeekly[w] * custom.priceWeekly[w];
        sumOptimized += optimized.unitsSoldWeekly[w] * optimized.priceWeekly[w];

        cumulativeBase.push(sumBase);
        cumulativeCustom.push(sumCustom);
        cumulativeOptimized.push(sumOptimized);
    }

    if (chartWeeklyRevenue) {
        chartWeeklyRevenue.destroy();
    }

    chartWeeklyRevenue = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
            datasets: [
                {
                    label: 'Base Case (No Discount)',
                    data: cumulativeBase,
                    borderColor: colors.text,
                    backgroundColor: 'transparent',
                    borderWidth: 2,
                    borderDash: [5, 5],
                    tension: 0.2
                },
                {
                    label: 'Decaying (Custom)',
                    data: cumulativeCustom,
                    borderColor: colors.accentSecondary,
                    backgroundColor: 'rgba(139, 92, 246, 0.05)',
                    borderWidth: 3,
                    tension: 0.2,
                    fill: true
                },
                {
                    label: 'Optimized Strategy (AI)',
                    data: cumulativeOptimized,
                    borderColor: colors.accentPrimary,
                    backgroundColor: 'rgba(99, 102, 241, 0.05)',
                    borderWidth: 3,
                    tension: 0.2,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false // Using custom legend in HTML header
                },
                tooltip: {
                    backgroundColor: colors.tooltipBg,
                    titleColor: colors.text,
                    bodyColor: colors.text,
                    borderColor: colors.tooltipBorder,
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${formatCurrency(context.raw)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { color: colors.grid },
                    ticks: { color: colors.text }
                },
                y: {
                    grid: { color: colors.grid },
                    ticks: {
                        color: colors.text,
                        callback: function(value) { return formatCurrency(value); }
                    }
                }
            }
        }
    });
}

// CHART 2: STRATEGY COMPARISON BAR CHART
function renderStrategyComparisonChart(base, custom, optimized) {
    const ctx = document.getElementById('chart-strategy-comparison').getContext('2d');
    const colors = getChartColors();

    if (chartStrategyComparison) {
        chartStrategyComparison.destroy();
    }

    chartStrategyComparison = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Base Case', 'Decaying (Custom)', 'Optimized (AI)'],
            datasets: [
                {
                    label: 'Gross Revenue',
                    data: [base.revenue, custom.revenue, optimized.revenue],
                    backgroundColor: colors.accentSecondary,
                    borderRadius: 6
                },
                {
                    label: 'Net Profit',
                    data: [base.profit, custom.profit, optimized.profit],
                    backgroundColor: colors.accentPrimary,
                    borderRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: colors.text, boxWidth: 12, padding: 15 }
                },
                tooltip: {
                    backgroundColor: colors.tooltipBg,
                    borderColor: colors.tooltipBorder,
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${formatCurrency(context.raw)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: colors.text }
                },
                y: {
                    grid: { color: colors.grid },
                    ticks: {
                        color: colors.text,
                        callback: function(value) { return formatCurrency(value); }
                    }
                }
            }
        }
    });
}

// CHART 3: SIMULATOR WEEKLY RUNOFF GRAPH
function renderInventoryRunoffChart(base, custom, optimized) {
    const ctx = document.getElementById('chart-inventory-runoff').getContext('2d');
    const colors = getChartColors();

    if (chartInventoryRunoff) {
        chartInventoryRunoff.destroy();
    }

    chartInventoryRunoff = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Start', 'Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
            datasets: [
                {
                    label: 'Base (No Discount)',
                    data: base.stockWeekly,
                    borderColor: colors.text,
                    borderWidth: 2,
                    borderDash: [5, 5],
                    fill: false,
                    tension: 0.1
                },
                {
                    label: 'Decaying (Custom)',
                    data: custom.stockWeekly,
                    borderColor: colors.accentSecondary,
                    borderWidth: 3,
                    fill: false,
                    tension: 0.1
                },
                {
                    label: 'Optimized (AI)',
                    data: optimized.stockWeekly,
                    borderColor: colors.accentTertiary,
                    borderWidth: 3,
                    fill: false,
                    tension: 0.1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: colors.text, boxWidth: 12, padding: 15 }
                },
                tooltip: {
                    backgroundColor: colors.tooltipBg,
                    borderColor: colors.tooltipBorder,
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.raw} units`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { color: colors.grid },
                    ticks: { color: colors.text }
                },
                y: {
                    grid: { color: colors.grid },
                    ticks: { color: colors.text }
                }
            }
        }
    });
}

// CHART 4: DEMAND CURVE (ELASTICITY TAB)
function renderElasticityCurves(prices, demandQty, revenues, profits, cogs, optimalPrice, simulatedPrice) {
    const ctxDemand = document.getElementById('chart-demand-curve').getContext('2d');
    const ctxProfit = document.getElementById('chart-profit-curve').getContext('2d');
    const colors = getChartColors();

    if (chartDemandCurve) {
        chartDemandCurve.destroy();
    }
    if (chartProfitCurve) {
        chartProfitCurve.destroy();
    }

    // Selected price metrics
    const currentPriceIdx = prices.findIndex(p => p >= simulatedPrice);
    const selectedQty = currentPriceIdx !== -1 ? demandQty[currentPriceIdx] : 0;
    const selectedRev = currentPriceIdx !== -1 ? revenues[currentPriceIdx] : 0;
    const selectedProfit = currentPriceIdx !== -1 ? profits[currentPriceIdx] : 0;

    // 1. Demand Curve Plot
    chartDemandCurve = new Chart(ctxDemand, {
        type: 'line',
        data: {
            labels: prices,
            datasets: [
                {
                    label: 'Demand Volume Q(P)',
                    data: demandQty,
                    borderColor: colors.accentTertiary,
                    backgroundColor: 'transparent',
                    borderWidth: 3,
                    tension: 0.2
                },
                {
                    label: 'Selected Price Point',
                    data: [{ x: simulatedPrice, y: selectedQty }],
                    pointBackgroundColor: colors.accentPrimary,
                    pointBorderColor: '#fff',
                    pointRadius: 8,
                    pointHoverRadius: 10,
                    showLine: false,
                    type: 'scatter'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: colors.tooltipBg,
                    borderColor: colors.tooltipBorder,
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            if (context.dataset.type === 'scatter') {
                                return `Current Price: $${simulatedPrice} | Sales: ${selectedQty} units`;
                            }
                            return `Price: $${context.label} | Demand: ${context.raw} units`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    type: 'linear',
                    position: 'bottom',
                    grid: { color: colors.grid },
                    ticks: {
                        color: colors.text,
                        callback: function(value) { return '$' + value; }
                    },
                    title: { display: true, text: 'Price ($)', color: colors.text, font: { weight: 'bold' } }
                },
                y: {
                    grid: { color: colors.grid },
                    ticks: { color: colors.text },
                    title: { display: true, text: 'Units Sold (Qty)', color: colors.text, font: { weight: 'bold' } }
                }
            }
        }
    });

    // 2. Revenue and Profit Curves Plot
    chartProfitCurve = new Chart(ctxProfit, {
        type: 'line',
        data: {
            labels: prices,
            datasets: [
                {
                    label: 'Projected Revenue',
                    data: revenues,
                    borderColor: colors.accentSecondary,
                    borderWidth: 2,
                    tension: 0.2,
                    fill: false
                },
                {
                    label: 'Projected Net Profit',
                    data: profits,
                    borderColor: colors.accentSuccess,
                    borderWidth: 3,
                    tension: 0.2,
                    fill: false
                },
                {
                    label: 'Selected Price Point',
                    data: [{ x: simulatedPrice, y: selectedProfit }],
                    pointBackgroundColor: colors.accentPrimary,
                    pointBorderColor: '#fff',
                    pointRadius: 7,
                    pointHoverRadius: 9,
                    showLine: false,
                    type: 'scatter'
                },
                {
                    label: 'Optimal Price Point',
                    data: [{ x: optimalPrice, y: (optimalPrice - cogs) * Math.max(0, Math.round(document.getElementById('el-max-demand').value - document.getElementById('el-sensitivity').value * optimalPrice)) }],
                    pointBackgroundColor: colors.accentSuccess,
                    pointBorderColor: '#fff',
                    pointRadius: 7,
                    pointHoverRadius: 9,
                    showLine: false,
                    type: 'scatter'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: colors.text, boxWidth: 12 }
                },
                tooltip: {
                    backgroundColor: colors.tooltipBg,
                    borderColor: colors.tooltipBorder,
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            if (context.dataset.label === 'Selected Price Point') {
                                return `Selected Price: $${simulatedPrice} | Profit: ${formatCurrency(selectedProfit)}`;
                            }
                            if (context.dataset.label === 'Optimal Price Point') {
                                return `Optimal Price: $${optimalPrice.toFixed(2)} | Max Profit: ${formatCurrency(context.raw)}`;
                            }
                            return `${context.dataset.label}: ${formatCurrency(context.raw)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    type: 'linear',
                    position: 'bottom',
                    grid: { color: colors.grid },
                    ticks: {
                        color: colors.text,
                        callback: function(value) { return '$' + value; }
                    },
                    title: { display: true, text: 'Price ($)', color: colors.text, font: { weight: 'bold' } }
                },
                y: {
                    grid: { color: colors.grid },
                    ticks: {
                        color: colors.text,
                        callback: function(value) { return formatCurrency(value); }
                    },
                    title: { display: true, text: 'Projected Value ($)', color: colors.text, font: { weight: 'bold' } }
                }
            }
        }
    });
}
