@echo off
echo ===================================================
echo Pushing OptiPrice Project to GitHub...
echo ===================================================
echo.

REM Try using the absolute path to Git
"C:\Program Files\Git\cmd\git.exe" push -u origin main

if %errorlevel% neq 0 (
    echo.
    echo Default path failed. Attempting to use system git...
    git push -u origin main
)

echo.
echo ===================================================
echo Process Complete.
echo ===================================================
pause
