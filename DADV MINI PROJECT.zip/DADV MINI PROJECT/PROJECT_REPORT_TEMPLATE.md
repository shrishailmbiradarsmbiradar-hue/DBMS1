# OptiPrice: Retail Markdown Clearance & Pricing Strategy Dashboard
## Project Analysis & System Architecture Report

---

## 1. Executive Summary
**OptiPrice** is an interactive, responsive retail analytics and decision-support web application. It is designed to assist retail managers and pricing strategists in:
*   Modeling price elasticity and optimizing regular product pricing.
*   Simulating weekly markdown clearance schedules over a 6-week window.
*   Running optimization algorithms to discover the profit-maximizing discount schedules.
*   Identifying and acting on slow-moving inventory candidates.

The tool provides an intuitive graphical user interface (GUI) with real-time feedback loops, backed by economic pricing models and search-space algorithms.

---

## 2. Core Functional Modules

### A. Overview Dashboard
*   **KPI Ribbons**: Displays real-time calculations for:
    *   *Projected Revenue* (reclaimed value).
    *   *Gross Margin %* (overall profitability).
    *   *Sell-Through Rate (STR)* (percentage of stock successfully liquidated).
    *   *Markdown Cost* (the dollar amount given away in discounts).
*   **Weekly Clearance Comparison Chart**: Visually compares cumulative weekly revenue for three options:
    1.  *Base Case* (No discounts).
    2.  *Decaying Scenario* (User-defined custom progressive discounts).
    3.  *Optimized Strategy* (AI/Algorithm-suggested profit-maximizing discounts).
*   **AI Strategy Advisor**: Provides qualitative guidelines and recommendations dynamically compiled from the selected product scenario.

### B. Clearance Markdown Simulator
*   Allows the pricing manager to specify key inputs:
    *   *Initial Inventory Units*
    *   *Original Retail Price*
    *   *Unit Cost (COGS)*
    *   *Base Weekly Sales Velocity*
    *   *Price Elasticity (Sensitivity)*
*   **Interactive Discount Sliders**: Sliders for Weeks 1 through 6 allow fine-grained simulation of runoff curves.
*   **Clearance Runoff Pattern Graph**: Renders the depletion of stock over the 6-week campaign, showing whether the inventory will successfully clear.
*   **Strategy Comparison Matrix**: A detailed tabular summary comparing key metrics (Revenue, Margin, STR, Unsold Units) side-by-side.

### C. Price Elasticity & Regular Optimizer
*   Models consumer demand response curves prior to markdown clearance campaigns.
*   Uses a **Linear Demand Curve**: $Q(P) = A - B \cdot P$.
*   Calculates the analytical maximum profit price ($P^*$) using calculus.
*   Visualizes both the **Demand Curve (Price vs Qty)** and the **Revenue & Profit Curves** with Chart.js to guide standard pricing decisions.

### D. Slow-Moving Inventory Alert Panel
*   Acts as a triage dashboard for aging stock.
*   Classifies items into three categories based on age and sell-through rate (STR):
    *   🟢 *Healthy Inventory* (Low age or high STR).
    *   🟡 *Markdown Candidate* (Moderate age, lagging STR).
    *   🔴 *Urgent Clearance* (High age, very low STR).
*   Supports search and category filtering.
*   Enables **Bulk Markdowns** (e.g., applying 15%, 30%, or optimized strategic discounts to multiple checked items simultaneously).

---

## 3. Mathematical & Algorithmic Models

### A. Power-Law Clearance Runoff Model
Clearance velocity increases non-linearly as discounts deepen. To model this, the simulator implements a weekly demand acceleration formula:

$$Q_t = Q_{\text{base}, t} \cdot (1 - d_t)^{-e}$$

Where:
*   $Q_t$ is the units demanded in week $t$.
*   $Q_{\text{base}, t}$ is the baseline demand decayed over time: $Q_{\text{base}, t} = Q_{\text{base}, 0} \cdot 0.95^t$ (representing the fading novelty or relevance of clearance stock).
*   $d_t$ is the discount rate in week $t$ (expressed as a fraction, $0.0 \le d_t \le 0.90$).
*   $e$ is the price elasticity coefficient (sensitivity parameter).

### B. Clearance Schedule Optimizer (Grid Search)
To find the global profit-maximizing schedule, the dashboard features an exhaustive optimization algorithm. 
*   **Rule of Progressive Markdowns**: Retail clearance discounts must be non-decreasing over time ($d_{t} \le d_{t+1}$) to avoid customer frustration and match buying patterns.
*   **Search Space**: Evaluates combinations of discount steps ($0\%, 10\%, 20\%, \dots, 80\%$) over a 6-week period. This yields exactly **3,003 valid non-decreasing paths** (calculated using combinations with repetition: $\binom{n+r-1}{r}$).
*   **Execution Time**: Evaluated in **under 1ms** directly in the browser via JavaScript recursion, returning the global profit-maximizing path.

### C. Analytical Regular Profit Maximizer
Before products go into markdown, the regular pricing is optimized.
*   **Demand Formula**: $Q(P) = A - B \cdot P$
*   **Profit Formula**: $\Pi(P) = (P - \text{COGS}) \cdot (A - B \cdot P)$
*   **Calculus Derivation**:
    $$\frac{d\Pi}{dP} = A - 2 \cdot B \cdot P + B \cdot \text{COGS} = 0$$
    $$P^* = \frac{A + B \cdot \text{COGS}}{2B} = \frac{A}{2B} + \frac{\text{COGS}}{2}$$
*   This analytical optimal price ($P^*$) is solved dynamically in real time when adjusting the sliders on the Pricing Elasticity tab.

---

## 4. Built-in Scenario Presets

The dashboard provides four distinct retail scenarios out-of-the-box:

1.  **Spring Apparel End-of-Season**:
    *   *Parameters*: Original Price = \$80, COGS = \$35, Elasticity = 2.2, Initial Inventory = 1000.
    *   *Challenge*: High storage footprint and rapid decay in appeal.
2.  **Consumer Electronics EOL Upgrade Cycle**:
    *   *Parameters*: Original Price = \$299, COGS = \$180, Elasticity = 1.5, Initial Inventory = 300.
    *   *Challenge*: High asset value with low price elasticity, meaning margin drops quickly if discounted too deep.
3.  **Fresh Grocery Surplus & Perishables**:
    *   *Parameters*: Original Price = \$12.99, COGS = \$5.50, Elasticity = 3.2, Initial Inventory = 2000.
    *   *Challenge*: Very short shelf life (1.5 weeks remaining). High elasticity allows rapid volume clearance.
4.  **Home Decor & Furnishing Clearance**:
    *   *Parameters*: Original Price = \$160, COGS = \$70, Elasticity = 1.8, Initial Inventory = 500.
    *   *Challenge*: Large physical holding costs but low style depreciation.

---

## 5. Technical Implementation Details

*   **Structure**: Clean semantic HTML5 elements representing the application layout (`<aside>`, `<main>`, `<section>`, `<header>`).
*   **Styling**: Modern, responsive vanilla CSS.
    *   Features CSS Custom Properties for dynamic styling.
    *   Responsive layouts using CSS Grid and Flexbox.
    *   Includes dual-theme support (**Light** and **Dark** modes).
*   **Charts**: Interfaced with Chart.js (via CDN) using canvas renderers, updating dynamically upon slide adjustments or preset changes.
*   **Data Parsing**: Written in pure ES6 JavaScript, encapsulating the simulator state, grid-search recursion, sorting handlers, and responsive layout switching.
